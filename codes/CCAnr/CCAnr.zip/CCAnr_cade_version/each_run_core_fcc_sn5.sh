#!/bin/bash

./runsolver --timestamp --use-pty -C $4 -o $3 ./CCAnr -inst $1 -seed $2 -ls_no_improv_steps '200000' -swt_p '0.3' -swt_q '0.7' -swt_threshold '50'
