./runsolver --timestamp --use-pty -C $4 -o $3 ./CCAnr -inst $1 -seed $2 -ls_no_improv_steps '5000000' -swt_p '0.40' -swt_q '0.77' -swt_threshold '825'
